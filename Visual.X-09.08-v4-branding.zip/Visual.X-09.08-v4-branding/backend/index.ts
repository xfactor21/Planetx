import { router, json, error, secrets } from '@appdeploy/sdk';

const BASE = 'https://partner-content-api.epidemicsound.com/v0';

async function getApiKey() {
    const names = await secrets.listSecretNames();
    if (!names.includes('EPIDEMIC_API_KEY')) return null;
    return secrets.readSecret('EPIDEMIC_API_KEY');
}

async function epidemic(path: string, user?: string) {
    const apiKey = await getApiKey();
    if (!apiKey) return { missing: true as const };
    const headers: Record<string, string> = {
        Accept: 'application/json',
        Authorization: `Bearer ${apiKey}`,
    };
    if (user) headers['x-partner-user-id'] = user;
    const response = await fetch(`${BASE}${path}`, { headers });
    const text = await response.text();
    let data: unknown = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
    return { missing: false as const, ok: response.ok, status: response.status, data };
}

function normalizeTracks(raw: any) {
    const list = Array.isArray(raw) ? raw : raw?.tracks || raw?.items || raw?.results || raw?.data || [];
    return (Array.isArray(list) ? list : []).map((track: any) => ({
        id: String(track.id ?? track.trackId ?? track.recordingId ?? ''),
        title: String(track.title ?? track.name ?? 'Untitled'),
        artist: Array.isArray(track.artists)
            ? track.artists.map((artist: any) => artist?.name || artist).filter(Boolean).join(', ')
            : String(track.artist?.name ?? track.artist ?? track.creator?.name ?? 'Epidemic Sound'),
        bpm: Number(track.bpm ?? track.tempo ?? 0) || null,
        duration: Number(track.duration ?? track.durationMs ?? track.length ?? 0) || null,
        isPreviewOnly: Boolean(track.isPreviewOnly),
        image: track.imageUrl ?? track.coverUrl ?? track.cover?.url ?? track.image?.url ?? null,
    })).filter((track: any) => track.id);
}

export const handler = router({
    'GET /api/catalog/status': [
        async () => json({ provider: 'Epidemic Sound', configured: Boolean(await getApiKey()) }),
    ],
    'GET /api/catalog/search': [
        async ({ query }) => {
            const term = (query.q || '').trim();
            if (term.length < 2) return error('Enter at least 2 characters.', 400);
            const result = await epidemic(`/tracks/search?limit=12&term=${encodeURIComponent(term)}`, query.user);
            if (result.missing) return json({ configured: false, tracks: [] });
            if (!result.ok) return error(`Epidemic Sound search failed (${result.status}).`, result.status);
            return json({ configured: true, tracks: normalizeTracks(result.data) });
        },
    ],
    'GET /api/catalog/track/:id': [
        async ({ params, query }) => {
            const result = await epidemic(`/tracks/${encodeURIComponent(params.id)}/download?format=mp3&quality=normal`, query.user);
            if (result.missing) return error('Epidemic Sound is not configured.', 503);
            if (!result.ok) return error(`Track access failed (${result.status}).`, result.status);
            const data = result.data as { url?: string; expires?: string };
            return json({ url: data.url, expires: data.expires });
        },
    ],
});