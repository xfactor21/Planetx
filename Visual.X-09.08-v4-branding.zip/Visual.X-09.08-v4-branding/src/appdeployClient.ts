type ApiResponse<T = any> = { data: T };

async function get<T = any>(url: string): Promise<ApiResponse<T>> {
  const response = await fetch(url, { headers: { accept: 'application/json' } });
  if (!response.ok) {
    throw new Error(`Request failed (${response.status})`);
  }
  return { data: (await response.json()) as T };
}

export const api = { get };
