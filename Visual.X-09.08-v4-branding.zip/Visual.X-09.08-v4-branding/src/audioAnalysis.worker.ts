import{analyzePCM}from'./audioAnalysisCore';
import type{SongDNA}from'./audioAnalysis';
type WorkerRequest={sampleRate:number;duration:number;channels:Float32Array[];preferredBpm:number|null};
type WorkerMessage={type:'progress';value:number}|{type:'result';dna:SongDNA}|{type:'error';message:string};
type WorkerScope={onmessage:((event:MessageEvent<WorkerRequest>)=>void)|null;postMessage:(message:WorkerMessage)=>void};
const scope=globalThis as unknown as WorkerScope;
scope.onmessage=event=>{try{const{sampleRate,duration,channels,preferredBpm}=event.data,length=channels[0]?.length||0,mono=new Float32Array(length),gain=1/Math.max(1,channels.length);for(const ch of channels)for(let i=0;i<length;i++)mono[i]+=ch[i]*gain;const dna=analyzePCM(mono,sampleRate,duration,value=>scope.postMessage({type:'progress',value}),undefined,preferredBpm);scope.postMessage({type:'result',dna})}catch(e){scope.postMessage({type:'error',message:e instanceof Error?e.message:'Audio analysis failed.'})}};
