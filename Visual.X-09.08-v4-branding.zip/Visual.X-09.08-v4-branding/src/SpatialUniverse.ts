import * as THREE from 'three';
import type { Cue, LiveFrame } from './directorEngine';
import type { PerformancePlan, WorldVisit } from './performancePlanner';

export type JourneyPhase = 'hold' | 'observe' | 'depart' | 'traverse' | 'arrive';
export type JourneyState = { active: boolean; phase: JourneyPhase; progress: number; direction: THREE.Vector3; destination: THREE.Vector3 | null; origin: THREE.Vector3; speed: number; route: 'open' | 'arc' | 'dive' | 'tunnel' | 'fracture' };
type Node = { visit: WorldVisit; anchor: THREE.Vector3; group: THREE.Group; mats: THREE.MeshBasicMaterial[]; beacon: THREE.Mesh; memory: boolean };

const COLORS = [0x22d3ee, 0xff2ba6, 0x8b5cf6, 0x62e8ff, 0xff4bd8, 0x7aff8d, 0xff8a3d, 0xffd166, 0x8efff0, 0x6c63ff, 0xff356f, 0xd16cff];
const C = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const S = (q: number) => q * q * (3 - 2 * q);

export class SpatialUniverse {
  root = new THREE.Group();
  private travelRoot = new THREE.Group();
  private travel: THREE.Points;
  private travelMat: THREE.PointsMaterial;
  private travelPos: THREE.BufferAttribute;
  private route: THREE.Line;
  private routeMat: THREE.LineBasicMaterial;
  private routePos: THREE.BufferAttribute;
  private nodes: Node[] = [];
  private plan: PerformancePlan | null = null;
  private eye = new THREE.Vector3();
  private tmp = new THREE.Vector3();
  private dir = new THREE.Vector3(0, 0, -1);
  private rng: number;

  constructor(scene: THREE.Scene, seed: number) {
    this.rng = seed || 1;
    scene.add(this.root, this.travelRoot);
    const a: number[] = [];
    for (let i = 0; i < 260; i++) a.push((this.R() - .5) * 18, (this.R() - .5) * 10, -26 + this.R() * 32);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(a, 3));
    this.travelPos = g.getAttribute('position') as THREE.BufferAttribute;
    this.travelMat = new THREE.PointsMaterial({ size: .03, color: 0x8edfff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    this.travel = new THREE.Points(g, this.travelMat);
    const rg = new THREE.BufferGeometry();
    rg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(48 * 3), 3));
    this.routePos = rg.getAttribute('position') as THREE.BufferAttribute;
    this.routeMat = new THREE.LineBasicMaterial({ color: 0xff4bd8, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    this.route = new THREE.Line(rg, this.routeMat);
    this.travelRoot.add(this.travel, this.route);
    this.travelRoot.visible = false;
  }

  private R() { this.rng = (this.rng * 1664525 + 1013904223) >>> 0; return this.rng / 4294967296; }
  private mat(mats: THREE.MeshBasicMaterial[], color: number, opacity = .1) { const m = new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }); mats.push(m); return m; }

  private landmark(v: WorldVisit, i: number) {
    const g = new THREE.Group(), mats: THREE.MeshBasicMaterial[] = [], color = COLORS[(v.worldIndex * 3 + i) % COLORS.length], m = (o = .1) => this.mat(mats, color, o);
    const add = (mesh: THREE.Mesh) => { g.add(mesh); return mesh; };
    switch (v.worldIndex % 18) {
      case 0: for (let k = 0; k < 2; k++) { const r = add(new THREE.Mesh(new THREE.TorusGeometry(1.15 + k * .65, .035, 6, 64), m(.09))); r.rotation.set(.7 + k * .42, k * .7, .2); } add(new THREE.Mesh(new THREE.IcosahedronGeometry(.45, 1), m(.13))); break;
      case 1: for (let k = 0; k < 4; k++) { const b = add(new THREE.Mesh(new THREE.BoxGeometry(.42, 1.7 + k * .55, .42), m(.1))); b.position.set((k - 1.5) * .72, (k % 2) * .42, 0); } break;
      case 2: for (let k = 0; k < 3; k++) { const a = add(new THREE.Mesh(new THREE.TorusGeometry(1.35 + k * .38, .025, 6, 56), m(.085))); a.scale.y = 1.55; a.rotation.x = Math.PI / 2; a.position.x = (k - 1) * .6; } break;
      case 3: for (let k = 0; k < 5; k++) { const x = add(new THREE.Mesh(new THREE.OctahedronGeometry(.42 + k * .08, 0), m(.1))); x.position.set(Math.sin(k * 1.7) * 1.25, (k - 2) * .48, Math.cos(k) * .55); } break;
      case 4: { const hole = add(new THREE.Mesh(new THREE.SphereGeometry(.8, 18, 12), new THREE.MeshBasicMaterial({ color: 0x000000 }))); hole.scale.z = .55; const r = add(new THREE.Mesh(new THREE.TorusGeometry(1.25, .07, 8, 80), m(.16))); r.rotation.x = 1.1; break; }
      case 5: { const p = add(new THREE.Mesh(new THREE.PlaneGeometry(4.6, 3.2, 9, 7), m(.08))); p.rotation.x = -1.15; const s = add(new THREE.Mesh(new THREE.IcosahedronGeometry(.55, 1), m(.15))); s.position.set(0, 1.1, -.7); break; }
      case 6: for (let k = 0; k < 4; k++) { const r = add(new THREE.Mesh(new THREE.TorusGeometry(.7 + k * .48, .025, 6, 64), m(.08))); r.rotation.x = Math.PI / 2; r.scale.y = .5; r.position.y = -.7 + k * .18; } break;
      case 7: for (let k = 0; k < 6; k++) { const c = add(new THREE.Mesh(new THREE.CylinderGeometry(.04, .1, 1.8 + k * .35, 5), m(.09))); c.position.set(Math.sin(k * 1.4) * 1.05, (k % 3 - 1) * .55, Math.cos(k) * .5); c.rotation.z = (k % 2 ? 1 : -1) * .28; } break;
      case 8: for (let k = 0; k < 7; k++) { const r = add(new THREE.Mesh(new THREE.TorusGeometry(1.2 - k * .07, .02, 6, 50), m(.075))); r.position.z = -k * .4; r.rotation.z = k * .12; } break;
      case 9: { const r = add(new THREE.Mesh(new THREE.TorusGeometry(1.65, .18, 8, 90), m(.13))); r.rotation.set(.75, .25, .15); for (let k = 0; k < 4; k++) { const s = add(new THREE.Mesh(new THREE.BoxGeometry(.22, .12, .55), m(.09))); const a = k * Math.PI / 2; s.position.set(Math.cos(a) * 2.15, Math.sin(a) * 1.15, 0); } break; }
      case 10: for (let k = 0; k < 5; k++) { const x = add(new THREE.Mesh(new THREE.ConeGeometry(.48 + k * .06, 1 + k * .24, 4), m(.1))); x.position.set((k - 2) * .62, -.6 + (k % 2) * .4, -.2 * k); x.rotation.y = k * .42; } break;
      case 11: for (let k = 0; k < 5; k++) { const x = add(new THREE.Mesh(new THREE.ConeGeometry(.55 + k * .06, .75 + k * .1, 7), m(.1))); x.position.set(Math.cos(k * 1.2) * 1.35, Math.sin(k * .9) * .75, Math.sin(k) * .5); x.rotation.z = Math.PI; } break; case 12: for(let k=0;k<6;k++){const b=add(new THREE.Mesh(new THREE.BoxGeometry(.24,1.2+k*.2,.24),m(.1)));b.position.set((k-2.5)*.48,Math.sin(k)*.28,-k*.16);b.rotation.z=(k-2.5)*.04;}break; case 13: for(let k=0;k<7;k++){const r=add(new THREE.Mesh(new THREE.ConeGeometry(.18,.95+k*.1,5),m(.09)));const a=k*.9;r.position.set(Math.cos(a)*(1+k*.14),(k-3)*.28,Math.sin(a)*.6);r.rotation.z=(k%2?1:-1)*.3;}break; case 14: for(let k=0;k<6;k++){const s=add(new THREE.Mesh(new THREE.SphereGeometry(.2+k*.045,10,8),m(.1)));const a=k*Math.PI/3;s.position.set(Math.cos(a)*(1.1+k*.14),Math.sin(a*.7)*.8,Math.sin(a)*(1.1+k*.14));}break; case 15: for(let k=0;k<6;k++){const o=add(new THREE.Mesh(new THREE.OctahedronGeometry(.28+k*.04,0),m(.1)));const side=k%2?1:-1;o.position.set(side*(.55+Math.floor(k/2)*.42),(k%3-1)*.42,-.18*k);o.rotation.y=k*.5;}break; case 16: for(let k=0;k<7;k++){const b=add(new THREE.Mesh(new THREE.BoxGeometry(.72,.12,.2),m(.09)));const a=-1.2+k*.4;b.position.set(Math.sin(a)*2.1,Math.cos(a)*.65,-.25*k);b.rotation.y=a;}break; default: for(let k=0;k<8;k++){const c=add(new THREE.Mesh(new THREE.CylinderGeometry(.04,.1,.9+k*.09,5),m(.085)));c.position.set((k%4-1.5)*.55,(Math.floor(k/4)-.5)*.7,-(k%3)*.3);c.rotation.z=(k%4-1.5)*.08;}break;
    }
    for (let k = 0; k < 3; k++) { const p = add(new THREE.Mesh(new THREE.IcosahedronGeometry(.09 + .035 * k, 0), m(.06))); const a = k * 2.1 + i * .7, r = 1.8 + k * .5; p.position.set(Math.cos(a) * r, Math.sin(a * .8) * r * .38, Math.sin(a) * r * .5); }
    const beacon = add(new THREE.Mesh(new THREE.TorusGeometry(2.05, .025, 6, 72), this.mat(mats, COLORS[(v.worldIndex + 5) % COLORS.length], .04)));
    beacon.rotation.x = 1.08;
    g.scale.setScalar(1.25 + (v.seed % 7) * .1);
    this.root.add(g);
    return { visit: v, anchor: new THREE.Vector3(), group: g, mats, beacon, memory: false };
  }

  private clear() { for (const n of this.nodes) { n.group.removeFromParent(); n.group.traverse(o => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); }); n.mats.forEach(m => m.dispose()); } this.nodes = []; }

  setPlan(p: PerformancePlan | null) {
    this.clear(); this.plan = p; this.eye.set(0, 0, 0);
    if (!p?.worlds.length) return;
    let previous = new THREE.Vector3();
    for (let i = 0; i < p.worlds.length; i++) {
      const v = p.worlds[i], n = this.landmark(v, i);
      if (i === 0) n.anchor.set(0, 0, 0); else {
        let recalled: THREE.Vector3 | null = null;
        for (let j = i - 2; j >= 0; j--) if (p.worlds[j].worldIndex === v.worldIndex) { recalled = this.nodes[j].anchor; break; }
        if (recalled && ((v.seed >>> 3) & 1) === 1) { n.anchor.copy(recalled).add(new THREE.Vector3((this.R() - .5) * 4, (this.R() - .5) * 2, (this.R() - .5) * 4)); n.memory = true; }
        else { const yaw = this.R() * Math.PI * 2, pitch = (this.R() - .5) * .55, dist = 24 + this.R() * 13; this.tmp.set(Math.cos(yaw) * Math.cos(pitch), Math.sin(pitch), Math.sin(yaw) * Math.cos(pitch)).multiplyScalar(dist); n.anchor.copy(previous).add(this.tmp); }
      }
      n.group.position.copy(n.anchor); n.group.rotation.set(this.R() * .3, this.R() * Math.PI * 2, this.R() * .2); previous = n.anchor.clone(); this.nodes.push(n);
    }
    this.root.position.set(0, 0, 0);
  }

  private indexAt(t: number) { if (!this.plan?.worlds.length) return -1; let idx = 0; for (let i = 0; i < this.plan.worlds.length; i++) { if (this.plan.worlds[i].start <= t) idx = i; else break; } return idx; }
  private routeType(v: WorldVisit) { return v.transitionMode === 'fold' ? 'tunnel' : v.transitionMode === 'fracture' ? 'fracture' : v.transitionMode === 'orbit' ? 'arc' : v.transitionMode === 'invasion' ? 'dive' : 'open'; }

  private animateTravel(dt: number, speed: number, l: LiveFrame, progress: number) {
    const step = dt * (9 + speed * .8 + l.level * 20 + l.flux * 8);
    for (let i = 0; i < this.travelPos.count; i++) { let z = this.travelPos.getZ(i) + step; if (z > 5) z = -26; this.travelPos.setZ(i, z); }
    this.travelPos.needsUpdate = true;
    for (let i = 0; i < this.routePos.count; i++) { const q = i / Math.max(1, this.routePos.count - 1), wobble = Math.sin(q * Math.PI) * (1.25 + l.mid * 1.8); this.routePos.setXYZ(i, Math.sin(q * 8 + progress * 4) * wobble * .22, Math.cos(q * 6 + progress * 3) * wobble * .12, -q * (12 + speed * .6)); }
    this.routePos.needsUpdate = true;
  }

  update(t: number, dt: number, c: Cue, l: LiveFrame): JourneyState {
    const idx = this.indexAt(t);
    if (idx < 0 || !this.nodes.length) return { active: false, phase: 'hold', progress: 0, direction: this.dir.set(0, 0, -1), destination: null, origin: this.tmp.set(0, 0, 0), speed: 0, route: 'open' };
    const cur = this.nodes[idx], next = this.nodes[idx + 1] || null;
    let phase: JourneyPhase = 'hold', progress = 0, active = false, speed = 0;
    this.eye.copy(cur.anchor);
    if (next) {
      const lead = Math.max(4, next.visit.start - next.visit.transitionStart), observeLead = Math.min(10, Math.max(6, lead * .8 + 2)), observeStart = Math.max(cur.visit.start + 2, next.visit.transitionStart - observeLead);
      if (t >= observeStart && t < next.visit.start) {
        active = true; progress = C((t - observeStart) / Math.max(.1, next.visit.start - observeStart));
        phase = progress < .2 ? 'observe' : progress < .4 ? 'depart' : progress < .8 ? 'traverse' : 'arrive';
        const travel = C((progress - .18) / .82), e = S(travel);
        this.eye.lerpVectors(cur.anchor, next.anchor, e);
        this.dir.copy(next.anchor).sub(cur.anchor); const dist = this.dir.length(); if (dist > .001) this.dir.multiplyScalar(1 / dist); else this.dir.set(0, 0, -1);
        speed = dist / Math.max(1, next.visit.start - observeStart);
        this.travelRoot.visible = phase !== 'observe';
        this.travelMat.opacity = phase === 'traverse' ? C(.12 + l.level * .18 + c.onsetPulse * .12) : phase === 'depart' || phase === 'arrive' ? .065 : 0;
        this.travelMat.size = .024 + C(l.treble * .045 + c.onsetPulse * .02, 0, .08);
        this.routeMat.opacity = phase === 'traverse' ? .12 + c.phrasePulse * .12 : .05;
        this.animateTravel(dt, speed, l, progress);
        this.travelRoot.rotation.y = Math.atan2(this.dir.x, -this.dir.z) * .28;
        this.travelRoot.rotation.x = -Math.asin(C(this.dir.y, -1, 1)) * .2;
      } else this.travelRoot.visible = false;
    } else this.travelRoot.visible = false;

    this.root.position.copy(this.eye).multiplyScalar(-1);
    const dest = next ? next.anchor.clone().sub(this.eye) : null, origin = cur.anchor.clone().sub(this.eye);
    for (let i = 0; i < this.nodes.length; i++) {
      const n = this.nodes[i], current = i === idx, nextUp = i === idx + 1, second = i === idx + 2, past = i < idx;
      let op = current ? .018 : nextUp ? .075 : second ? .022 : past ? (idx - i <= 2 ? .012 : .003) : .008;
      if (nextUp && active) op = .08 + .28 * S(progress);
      if (n.memory && past) op += .01;
      for (const m of n.mats) m.opacity = op;
      n.group.visible = op > .002;
      n.group.rotation.y += dt * (.012 + (i % 3) * .005);
      const bm = n.beacon.material as THREE.MeshBasicMaterial;
      bm.opacity = nextUp ? .035 + (active ? .15 * S(progress) + .1 * c.phrasePulse : 0) : past && idx - i <= 1 ? .02 : .008;
      n.beacon.scale.setScalar(1 + (nextUp && active ? c.beatPulse * .08 + c.tonalPulse * .05 : 0));
    }
    return { active, phase, progress, direction: this.dir.clone(), destination: dest, origin, speed, route: next ? this.routeType(next.visit) : 'open' };
  }

  updateAmbient(t: number, dt: number) { this.travelRoot.visible = false; this.root.rotation.y = Math.sin(t * .02) * .015; for (const n of this.nodes) n.group.rotation.y += dt * .01; }
  dispose() { this.clear(); this.travel.geometry.dispose(); this.travelMat.dispose(); this.route.geometry.dispose(); this.routeMat.dispose(); this.root.removeFromParent(); this.travelRoot.removeFromParent(); }
}
