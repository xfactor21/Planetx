# Visual.X-09.08-v4-branding

Visual.X deterministic music world engine package with the v4 branding update.

## Current Live App

- Live URL: https://visual-x-g9w4nz.v2.appdeploy.ai/
- AppDeploy app id: `visual-x-g9w4nz`
- Branding deployment status: ready
- Branding AppDeploy snapshot: `1788835525401`
- UI version marker: `v4`
- Manifest version: `4.0.0`

## Branding Update

- Replaced the CSS-rendered `VISUAL.X` header in this package with the transparent visual.X wordmark asset.
- Kept the exact two-line tagline:
  - `Your Song.`
  - `A World That Only Exists Once.`
- Added `public/resources/new-transparent-visual-x-wordmark-asset.png`.
- Preserved the deterministic audio analysis, Three.js engine, director, choreography, and world systems.

## Safe Local Setup

1. Run `npm install`.
2. Run `npm run typecheck`.
3. Run `npm run build`.
4. Run `npm run dev` for local development or `npm run preview` after building.

Optional catalog/search secrets belong in a local `.env` file. Start from `.env.example`; do not commit real credentials.

## Packaging Notes

This ZIP excludes `.git`, `node_modules`, prior build folders, and the large local test audio file from the older handoff package. The public GitHub repository was still at commit `5101033890d55c0e2bc7150539118504cc2f1979` when this package was created, while the live AppDeploy branding snapshot is `1788835525401`.
