# Visual.X AppDeploy Source Manifest

App id: visual-x-g9w4nz
Source export version: v52 / 1788739394078
Live URL: https://visual-x-g9w4nz.v2.appdeploy.ai/
Export date: 2026-09-06

This repository now includes the actual editable AppDeploy source export supplied as `visual-x-g9w4nz-1788739394078-src.zip`.

## Included Source Files

- backend/index.ts
- index.html
- package.json
- postcss.config.js
- src/ActorSystem.ts
- src/App.tsx
- src/AudioWaveEntity.ts
- src/CameraRig.ts
- src/ChoreographyEngine.ts
- src/CompositionDirector.ts
- src/IndependentMotifSystem.ts
- src/PostPipeline.ts
- src/ProjectMBridge.ts
- src/ReactiveBehaviorSystem.ts
- src/RegionConstellationSystem.ts
- src/SpatialUniverse.ts
- src/TonalAccentSystem.ts
- src/VisualEngine.ts
- src/WorldIdentitySystem.ts
- src/audioAnalysis.ts
- src/audioAnalysis.worker.ts
- src/audioAnalysisCore.ts
- src/directorEngine.ts
- src/engineFramework.ts
- src/expandedWorlds.ts
- src/index.css
- src/main.tsx
- src/newRegions.ts
- src/performancePlanner.ts
- src/worldCatalog.ts
- src/worldModules.ts
- tailwind.config.js
- tests/tests.txt
- tsconfig.json
- vite.config.ts

## Reference Assets

The `app/` directory remains in the repository from the previous deployed-build package handoff. The editable project source is at the repository root and under `src/` and `backend/`.

