# Visual.X AppDeploy Source Manifest

App id: visual-x-g9w4nz
Source snapshot version: v62 / 1788835525401
Live URL: https://visual-x-g9w4nz.v2.appdeploy.ai/
Export date: 2026-09-08

This repository is the runnable v4 source handoff for the current Visual.X release-hardening build.

## Included Source Files

- backend/index.ts
- index.html
- package.json
- postcss.config.js
- public/resources/new-transparent-visual-x-wordmark-asset.png
- src/ActorSystem.ts
- src/App.tsx
- src/AudioWaveEntity.ts
- src/CameraRig.ts
- src/ChoreographyEngine.ts
- src/CompositionDirector.ts
- src/IndependentMotifSystem.ts
- src/PostPipeline.ts
- src/ProjectMBridge.ts
- src/ReactiveBehaviorSystem.ts
- src/RegionConstellationSystem.ts
- src/SpatialUniverse.ts
- src/TonalAccentSystem.ts
- src/VisualEngine.ts
- src/WorldIdentitySystem.ts
- src/audioAnalysis.ts
- src/audioAnalysis.worker.ts
- src/audioAnalysisCore.ts
- src/directorEngine.ts
- src/engineFramework.ts
- src/expandedWorlds.ts
- src/index.css
- src/main.tsx
- src/newRegions.ts
- src/performancePlanner.ts
- src/worldCatalog.ts
- src/worldModules.ts
- tailwind.config.js
- tests/tests.txt
- tsconfig.json
- vite.config.ts

## Reference Assets

The editable project source is at the repository root and under `src/`, `backend/`, and `public/`.


Visual.X v4.1 source patch: adds built-in xFactor demo-track selection using public planet.X-hosted audio. Build verification was not reproduced in this environment because dependencies were unavailable.
