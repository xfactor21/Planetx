# Visual.X AppDeploy Source Export - 09.08 v4

Export name: Visual.X-Hardening-09.08-v4-source
AppDeploy app id: visual-x-g9w4nz
Source AppDeploy version: v62 / 1788835525401
Live deployment: https://visual-x-g9w4nz.v2.appdeploy.ai/
Deployment status: READY

## v4 Release-Hardening Source Package

- Preserved the finalized Visual.X v4 header, wordmark, and tagline: "YOUR SONG. A World That Only Exists Once."
- Preserved Expert Mode as World, DNA, Director, and Live only.
- Preserved background privacy-safe analytics emission while keeping the removed Analytics page out of the UI.
- Added the live transparent Visual.X wordmark asset under `public/resources/`.
- Verified `npm install`, `npm run typecheck`, `npm run build`, and a local preview smoke check.

## Previous v3 Source Recovery Update

# Visual.X AppDeploy Source Export - 09.06 v3

Export name: visualX-09.06-v3-source-actual
AppDeploy app id: visual-x-g9w4nz
Source AppDeploy version: v52 / 1788739394078
Live deployment: https://visual-x-g9w4nz.v2.appdeploy.ai/
Deployment status: READY

## v3 Source Recovery Update

- Confirmed the user-provided ZIP `visual-x-g9w4nz-1788739394078-src.zip` is the actual editable AppDeploy source export.
- Extracted the source into `visualX-09.06-v3-source-actual`.
- Added the editable source project to GitHub while preserving the earlier v2 package/log handoff.
- Confirmed v52 is newer than the v51 AppDeploy build package previously documented in this repo.
- Added a local `@appdeploy/client` compatibility wrapper so the source builds outside AppDeploy.
- Fixed exported-source TypeScript strictness issues around camera cue typing, typed audio buffers, and local API response typing.
- Verified `npm install`, `npm run typecheck`, and `npm run build` pass locally.

## Previous v2 Package Handoff

Export name: visualX-09.06-v2-appdeploy-source
AppDeploy app id: visual-x-g9w4nz
Applied AppDeploy version: v51 / 1788415368061
Live deployment: https://visual-x-g9w4nz.v2.appdeploy.ai/
Deployment status at export: READY
Frontend errors: 0
Backend errors: 0
Network errors: 0

## Packaging Note

This package contains the current live deployed AppDeploy app assets plus a source manifest and work log generated from the applied AppDeploy source snapshot. The AppDeploy connector available in this session exposed source discovery/read inspection, but did not expose a direct complete source-folder download endpoint.

## AppDeploy Source Manifest

- backend/index.ts
- index.html
- package.json
- postcss.config.js
- src/ActorSystem.ts
- src/App.tsx
- src/AudioWaveEntity.ts
- src/CameraRig.ts
- src/ChoreographyEngine.ts
- src/CompositionDirector.ts
- src/IndependentMotifSystem.ts
- src/PostPipeline.ts
- src/ProjectMBridge.ts
- src/ReactiveBehaviorSystem.ts
- src/RegionConstellationSystem.ts
- src/SpatialUniverse.ts
- src/TonalAccentSystem.ts
- src/VisualEngine.ts
- src/WorldIdentitySystem.ts
- src/audioAnalysis.ts
- src/directorEngine.ts
- src/engineFramework.ts
- src/expandedWorlds.ts
- src/index.css
- src/main.tsx
- src/newRegions.ts
- src/performancePlanner.ts
- src/worldCatalog.ts
- src/worldModules.ts
- tailwind.config.js
- tests/tests.txt
- tsconfig.json
- vite.config.ts

## Latest Architecture

Visual.X remains a deterministic, local-first procedural music visualization engine. No AI or machine-learning inference was added. The runtime uses browser audio analysis, deterministic DSP features, seeded planning, procedural Three.js regions, camera rules, and UI state.

The current source snapshot includes a React/Vite frontend, a small AppDeploy backend for optional Epidemic Sound catalog access, Three.js rendering, deterministic song analysis, performance planning, region constellation management, static waveform horizon rendering, projectM integration as a subdued accent layer, and regression-style test notes.

## Latest Conversation Changelog

### 360 Region Constellation

- Reworked the active performance from one crowded central scene into multiple separated regions arranged around a 360-degree world.
- Added `RegionConstellationSystem` to maintain fixed spatial anchors per epoch.
- Desktop can show six simultaneous regions; smaller screens reduce the count to preserve readability.
- One region is treated as the hero/focus region while background regions remain visible at distance.
- Region sets refresh around each 60-second epoch so the full 18-region catalog can continue rotating into the experience.
- Region selection can use the performance plan when available and fills from the full world catalog deterministically.

### Static 360 Song Waveform Horizon

- Replaced the roaming waveform actor idea with a single static 360-degree waveform horizon.
- `AudioWaveEntity` builds a circular timeline from the full-song amplitude profile.
- The ring does not rotate or drift after creation.
- The completed portion brightens while the unplayed portion remains dimmer.
- A white playhead tracks actual playback time and updates immediately when seeking.
- The waveform is placed outside the active region constellation so it does not obstruct region performance.

### Camera Intelligence

- Camera focus now scores regions using bass, mids, highs, flux/onsets, tonal strength, harmonic motion, speed, and major section context.
- Focus changes occur roughly every 9-12 seconds, with a short hold so the camera does not wander continuously.
- Strong hero/drop events can trigger earlier focus changes when another region becomes more musically interesting.
- Camera transfers use wider reveal framing, then settle into a controlled orbit around the new hero region.
- The latest constellation camera path is designed to occasionally keep other regions in the background during focus transitions.

### World/Region Catalog

The catalog is currently 18 regions: Orbital System, Neon Monoliths, Ribbon Cathedral, Crystal Lattice, Singularity Void, Reactive Terrain, Plasma Ocean, Neural Grove, Dimensional Tunnel, Megastructure Ring, Fracture Desert, Floating Archipelago, Kinetic Causeway, Chroma Reef, Gravity Garden, Mirror Basin, Pulse Bridge, and Signal Forest.

### UI/UX Updates

- Viewer overlays are hidden by default.
- The visual viewer itself is now a primary play/pause surface for loaded songs.
- Viewer supports keyboard activation with Enter/Space.
- Viewer tool buttons are protected so clicking buttons does not accidentally toggle playback.
- The viewer is visually dominant and wrapped in a darker, cleaner planet.X/Visual.X palette.
- Controls were tightened around hot pink, violet, cyan, dark stage surfaces, compact buttons, and optional diagnostics.
- User-facing copy now emphasizes deterministic DSP and avoids implying AI behavior.

### Video-Review Findings Addressed

- Earlier recordings showed overcrowding, persistent central composition, too much projectM overlay behavior, and camera motion that could feel like movement for its own sake.
- The current pass addresses that by separating regions in space, making the camera choose one region at a time, reducing ordinary projectM dominance, and moving waveform representation out to a stable environmental horizon.
- The previous v6 findings around repeated radial/ring grammar, sparse transitions, projectM blue-washing, and insufficient camera variety remain part of the historical baseline, but v51 specifically targets the later congestion and subject-focus problems.

### Final Calibration Pass

- Deployment remained READY after the changes.
- AppDeploy QA returned zero frontend errors, zero backend errors, and zero network errors at export time.
- Current live URL remains https://visual-x-g9w4nz.v2.appdeploy.ai/.
- Current deployment status is preserved as READY; this packaging pass did not redeploy the app.
- Full visual judgment still requires human playback review with a 60-90 second recording because screenshots cannot prove long-form camera intelligence or musical readability.


## v4.1 pending — built-in xFactor demo tracks
- Added a third entry path: Try an xFactor Track.
- Initial hosted tracks: Glitch God and Digital Decay.
- Featured tracks use the same local DSP analysis/generation pipeline as uploads.
- Featured track analytics use song_source=featured.
- Epidemic Sound search remains separate and still requires EPIDEMIC_API_KEY server-side.
