# Visual-X
Visual.X AppDeploy v62 release-hardening source handoff and deterministic 360 music visualizer package.

## Current Build

- Live AppDeploy URL: https://visual-x-g9w4nz.v2.appdeploy.ai/
- AppDeploy app id: `visual-x-g9w4nz`
- Source snapshot version: `1788835525401` / v62
- Package name: `Visual.X-Hardening-09.08-v4-source`
- App/package version: v4 / `4.0.0`
- Earlier deployed-build ZIP handoff: https://d2ol7oe51mr4n9.cloudfront.net/user_3IH20kozE5JbuRBE4TF5U6oLtp8/60a49aa2-f5ff-4284-9fbd-ffa3bcf8d3e9.zip

## Constraint

Visual.X remains a deterministic procedural music visualizer. No AI or ML model was added to the runtime; the behavior described here is driven by DSP features, deterministic planning, procedural world systems, and choreography logic.

## Source Contents

- `src/` contains the editable React, Three.js, audio analysis, choreography, constellation, waveform, and camera source.
- `backend/` contains the AppDeploy backend entrypoint for optional catalog access.
- Root config files include Vite, TypeScript, Tailwind, PostCSS, and package metadata.
- `src/appdeployClient.ts` is a local compatibility wrapper for the AppDeploy-only frontend API client import.
- `tests/tests.txt` records the behavior checks used for the latest pass.
- `CHANGELOG.md` summarizes the latest work and calibration pass.
- `SOURCE-MANIFEST.md` records the AppDeploy source modules included.

## Verification

- `npm install`: passed
- `npm run typecheck`: passed
- `npm run build`: passed
- Local preview smoke check: passed, including wordmark/header, finalized tagline, and v4 display.
