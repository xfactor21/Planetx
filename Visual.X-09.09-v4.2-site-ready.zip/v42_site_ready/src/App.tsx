import { ChangeEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { api } from './catalogClient';
import { Activity, ChevronLeft, ChevronRight, Copy, Download, ExternalLink, Eye, EyeOff, LoaderCircle, Music2, Pause, Play, Search, Settings2, Share2, Shuffle, Square, Upload, Video, X } from 'lucide-react';
import { analyzeFile, type SongDNA } from './audioAnalysis';
import { Director, type Cue, type LiveFrame } from './directorEngine';
import { VisualEngine } from './VisualEngine';
import { detectQualityTier, type QualityTier } from './engineFramework';
import { createPerformancePlan, type PerformancePlan } from './performancePlanner';

type CatalogTrack = { id: string; title: string; artist: string; bpm: number | null; duration: number | null; isPreviewOnly: boolean; image: string | null };
type SongSource = 'upload' | 'search' | 'featured';
type FeaturedTrack = { id: string; title: string; artist: string; url: string };

const featuredTracks: FeaturedTrack[] = [
  { id: 'digital-decay', title: 'Digital Decay', artist: 'xFactor', url: 'https://www.planet-x.co/music-tracks/digital-decay.mp3' },
  { id: 'coming-down-that-hill', title: 'Coming Down That Hill', artist: 'xFactor', url: './featured/coming-down-that-hill.mp3' },
  { id: 'glitch-god', title: 'Glitch God', artist: 'xFactor', url: 'https://www.planet-x.co/music-tracks/glitch-god.mp3' },
  { id: 'ghost-in-the-machine', title: 'Ghost in the Machine', artist: 'xFactor', url: 'https://www.planet-x.co/music-tracks/ghost-in-the-machine.mp3' },
  { id: 'xs-in-my-head', title: 'Xs in My Head', artist: 'xFactor', url: './featured/xs-in-my-head.mp3' },
];
type RecordLength = 15 | 30 | 60 | 'full';
type Aspect = '9:16' | '1:1' | '16:9';
type RunIdentity = { generationId: string; worldId: string; songSource: SongSource | null; parentWorldId: string | null };

const pct = (v: number) => Math.round(v * 100);
const freshSeed = () => crypto.getRandomValues(new Uint32Array(1))[0] || 1;
const worldFromSeed = (seed: number) => `X-${(seed >>> 0).toString(16).toUpperCase().padStart(8, '0').slice(-4)}`;
const safeName = (s: string) => s.replace(/[^a-z0-9-_]+/gi, '-').replace(/^-+|-+$/g, '') || 'Visual-X';
const userId = () => {
  const key = 'visualx-partner-user';
  let value = localStorage.getItem(key);
  if (!value) {
    value = `vx-${crypto.randomUUID()}`;
    localStorage.setItem(key, value);
  }
  return value;
};
const sessionId = () => { const key = 'visualx-session-id'; let value = sessionStorage.getItem(key); if (!value) { value = `vxs-${crypto.randomUUID()}`; sessionStorage.setItem(key, value); } return value; };
const getLocalAnalytics = () => {
  try { return JSON.parse(localStorage.getItem('visualx-analytics-local') || '[]') as Record<string, unknown>[]; }
  catch { return []; }
};

function App() {
  const initialSeed = useRef(freshSeed());
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const rafRef = useRef<number | undefined>(undefined);
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const engineRef = useRef<VisualEngine | null>(null);
  const directorRef = useRef<Director | null>(null);
  const planRef = useRef<PerformancePlan | null>(null);
  const timeRef = useRef(0);
  const trackUrlRef = useRef<string | null>(null);
  const recordUrlRef = useRef<string | null>(null);
  const lastVisualTimeRef = useRef(Number.NaN);
  const freqRef = useRef<Uint8Array>(new Uint8Array(0));
  const pcmRef = useRef<Float32Array>(new Float32Array(2048));
  const prevRef = useRef<LiveFrame>({ bass: 0, mid: 0, treble: 0, level: 0, flux: 0 });
  const analysisRunRef = useRef(0);
  const searchRunRef = useRef(0);
  const trackLoadRunRef = useRef(0);
  const recordFinishRef = useRef<(() => void) | null>(null);
  const uiTimerRef = useRef<number | undefined>(undefined);
  const referralWorldRef = useRef(new URLSearchParams(window.location.search).get('ref')); 

  const [track, setTrack] = useState<{ name: string; url: string; size: number } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [audioReady, setAudioReady] = useState(false);
  const [analysisReady, setAnalysisReady] = useState(false);
  const ready = audioReady && analysisReady;
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(.82);
  const [visualSeed, setVisualSeed] = useState(initialSeed.current);
  const [generationId, setGenerationId] = useState(() => crypto.randomUUID());
  const [songSource, setSongSource] = useState<SongSource | null>(null);
  const [parentWorldId, setParentWorldId] = useState<string | null>(null);
  const [quality, setQuality] = useState<QualityTier>(detectQualityTier);
  const [diagnostics, setDiagnostics] = useState(false);
  const [dna, setDna] = useState<SongDNA | null>(null);
  const [status, setStatus] = useState('Choose a song to create a world');
  const [progress, setProgress] = useState(0);
  const [live, setLive] = useState<LiveFrame>(prevRef.current);
  const [cue, setCue] = useState<Cue | null>(null);
  const [catalogConfigured, setCatalogConfigured] = useState<boolean | null>(null);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CatalogTrack[]>([]);
  const [searching, setSearching] = useState(false);
  const [loadingTrack, setLoadingTrack] = useState<string | null>(null);
  const [catalogMessage, setCatalogMessage] = useState('');
  const [showOverlay, setShowOverlay] = useState(false);

  const [expert, setExpert] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [featuredOpen, setFeaturedOpen] = useState(false);
  const [recordOpen, setRecordOpen] = useState(false);
  const [recordLength, setRecordLength] = useState<RecordLength>(30);
  const [recordAspect, setRecordAspect] = useState<Aspect>('9:16');
  const [recording, setRecording] = useState(false);
  const [recordingProgress, setRecordingProgress] = useState(0);
  const [recordError, setRecordError] = useState('');
  const [recordBlob, setRecordBlob] = useState<Blob | null>(null);
  const [recordUrl, setRecordUrl] = useState<string | null>(null);
  const [recordMime, setRecordMime] = useState('video/webm');
  const [shareMessage, setShareMessage] = useState('');
  const [controlsVisible, setControlsVisible] = useState(true);
  const [leftOpen, setLeftOpen] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);
  useEffect(() => { if (!leftOpen && !rightOpen) return; const previous = document.body.style.overflow; document.body.style.overflow = 'hidden'; return () => { document.body.style.overflow = previous; }; }, [leftOpen, rightOpen]);

  const worldId = useMemo(() => worldFromSeed(visualSeed), [visualSeed]);
  const identityRef = useRef<RunIdentity>({ generationId, worldId, songSource, parentWorldId });
  identityRef.current = { generationId, worldId, songSource, parentWorldId };
  const currentSection = useMemo(() => dna?.sections.find(s => time >= s.start && time < s.end) || dna?.sections[dna.sections.length - 1] || null, [dna, time]);
  const metrics: [string, number][] = dna ? [['Energy', dna.energy], ['Brightness', dna.brightness], ['Aggression', dna.aggression], ['Rhythm', dna.rhythmicity], ['Punch', dna.punch], ['Spacious', dna.spaciousness], ['Complexity', dna.complexity], ['Low End', dna.lowEnd], ['Mid Presence', dna.midPresence], ['High Air', dna.highAir], ['Tension', dna.tension], ['Dynamics', dna.dynamicRange]] : [];

  const emit = (event: string, fields: Record<string, unknown> = {}) => {
    const i = identityRef.current;
    const payload = { event, client_id: userId(), anonymous_user_id: userId(), session_id: sessionId(), timestamp: new Date().toISOString(), source_surface: 'visual-x-app', path: window.location.pathname || '/', platform: /Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : 'desktop', generation_id: i.generationId, world_id: i.worldId, song_source: i.songSource, remix_parent_world_id: i.parentWorldId, referral_world_id: referralWorldRef.current, quality, ...fields };
    try { localStorage.setItem('visualx-analytics-local', JSON.stringify([...getLocalAnalytics().slice(-99), payload])); } catch {}
    void api.post('/api/analytics', payload).catch(() => {});
  };

  const revealControls = () => {
    setControlsVisible(true);
    if (uiTimerRef.current) window.clearTimeout(uiTimerRef.current);
    if (playing && !expert) uiTimerRef.current = window.setTimeout(() => setControlsVisible(false), 2800);
  };
  useEffect(() => {
    if (uiTimerRef.current) window.clearTimeout(uiTimerRef.current);
    if (!track || !playing || expert) { setControlsVisible(true); return; }
    uiTimerRef.current = window.setTimeout(() => setControlsVisible(false), 2800);
    return () => { if (uiTimerRef.current) window.clearTimeout(uiTimerRef.current); };
  }, [playing, expert, track]);
  useEffect(() => { api.get('/api/catalog/status').then(r => setCatalogConfigured(Boolean(r.data?.configured))).catch(() => setCatalogConfigured(false)); }, []);
  useEffect(() => {
    directorRef.current = dna ? new Director(dna, visualSeed) : null;
    const plan = dna ? createPerformancePlan(dna, visualSeed) : null;
    planRef.current = plan;
    engineRef.current?.setPerformancePlan(plan);
    engineRef.current?.setSongProfile(dna ? dna.frames.map(f => f.energy) : [], dna?.duration || 0);
    lastVisualTimeRef.current = Number.NaN;
    prevRef.current = { bass: 0, mid: 0, treble: 0, level: 0, flux: 0 };
    setCue(null);
  }, [dna, visualSeed]);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new VisualEngine(canvas, visualSeed, quality);
    engine.setDiagnosticMode(diagnostics);
    engine.setPerformancePlan(planRef.current);
    engine.setSongProfile(dna ? dna.frames.map(f => f.energy) : [], dna?.duration || 0);
    engineRef.current = engine;
    const resize = () => engine.resize();
    window.addEventListener('resize', resize);
    return () => { window.removeEventListener('resize', resize); engine.dispose(); engineRef.current = null; };
  }, [visualSeed, quality]);
  useEffect(() => { engineRef.current?.setDiagnosticMode(diagnostics); }, [diagnostics]);
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);
  useEffect(() => {
    const onFullscreen = () => { if (document.fullscreenElement) emit('fullscreen_entered'); requestAnimationFrame(() => engineRef.current?.resize()); };
    document.addEventListener('fullscreenchange', onFullscreen);
    return () => document.removeEventListener('fullscreenchange', onFullscreen);
  }, []);
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    setAudioReady(false); setAnalysisReady(false); setPlaying(false); timeRef.current = 0; setTime(0);
    if (track?.url) { audio.src = track.url; audio.load(); } else { audio.removeAttribute('src'); audio.load(); }
  }, [track?.url]);
  useEffect(() => () => {
    if (trackUrlRef.current) URL.revokeObjectURL(trackUrlRef.current);
    if (recordUrlRef.current) URL.revokeObjectURL(recordUrlRef.current);
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    void ctxRef.current?.close();
  }, []);

  const connect = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    let ctx = ctxRef.current;
    if (!ctx || ctx.state === 'closed') {
      ctx = new AudioContext(); ctxRef.current = ctx;
      analyserRef.current = ctx.createAnalyser(); analyserRef.current.fftSize = 2048; analyserRef.current.smoothingTimeConstant = .38;
      sourceRef.current = ctx.createMediaElementSource(audio); sourceRef.current.connect(analyserRef.current); analyserRef.current.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') await ctx.resume();
  };
  const readLive = (): LiveFrame => {
    const audio = audioRef.current, analyser = analyserRef.current;
    const mediaActive = Boolean(audio && !audio.paused && !audio.ended && audio.readyState >= 2);
    let bins: Uint8Array | null = null;
    if (analyser) { if (freqRef.current.length !== analyser.frequencyBinCount) freqRef.current = new Uint8Array(analyser.frequencyBinCount); bins = freqRef.current; analyser.getByteFrequencyData(bins as Uint8Array<ArrayBuffer>); }
    const band = (a: number, b: number) => { if (!bins) return 0; let sum = 0, count = 0; for (let i = a; i < Math.min(b, bins.length); i++) { sum += bins[i]; count++; } return count ? sum / count / 255 : 0; };
    let bass = band(1, 34), mid = band(34, 230), treble = band(230, 760), level = (bass + mid + treble) / 3;
    const frameTime = audio && Number.isFinite(audio.currentTime) ? audio.currentTime : timeRef.current;
    const frame = dna?.frames[Math.min((dna?.frames.length || 1) - 1, Math.max(0, Math.round((frameTime / Math.max(.001, dna?.duration || 1)) * ((dna?.frames.length || 1) - 1))))];
    if (frame && (!mediaActive || level < .012)) { bass = frame.low; mid = frame.mid; treble = frame.high; level = frame.energy; }
    const prev = prevRef.current;
    const flux = Math.min(1, frame?.flux ?? (Math.abs(bass - prev.bass) * 2.7 + Math.abs(mid - prev.mid) * 1.5 + Math.abs(treble - prev.treble) * 1.45));
    const out = { bass, mid, treble, level, flux }; prevRef.current = out; return out;
  };
  const readPCM = () => {
    const analyser = analyserRef.current; if (!analyser) return null;
    if (pcmRef.current.length !== analyser.fftSize) pcmRef.current = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(pcmRef.current as Float32Array<ArrayBuffer>); return pcmRef.current;
  };
  useEffect(() => {
    let lastUi = 0;
    const loop = (ms: number) => {
      const audio = audioRef.current, t = audio && Number.isFinite(audio.currentTime) ? audio.currentTime : timeRef.current;
      timeRef.current = t;
      const frame = readLive();
      if (dna) {
        const moved = !Number.isFinite(lastVisualTimeRef.current) || Math.abs(t - lastVisualTimeRef.current) > .0005;
        if (moved) {
          const nextCue = directorRef.current?.update(t, frame), pcm = readPCM();
          if (nextCue) engineRef.current?.update(t, nextCue, frame, pcm);
          lastVisualTimeRef.current = t;
          if (ms - lastUi > 110) { lastUi = ms; setLive(frame); if (nextCue) setCue(nextCue); }
        }
      } else engineRef.current?.updateAmbient(ms / 1000);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [dna]);

  const createRun = (source: SongSource, parent: string | null = null) => {
    const seed = freshSeed(), gid = crypto.randomUUID(), wid = worldFromSeed(seed);
    setVisualSeed(seed); setGenerationId(gid); setSongSource(source); setParentWorldId(parent);
    identityRef.current = { generationId: gid, worldId: wid, songSource: source, parentWorldId: parent };
    return { gid, wid };
  };
  const adoptFile = async (file: File, label: string | undefined, knownBpm: number | null | undefined, source: SongSource) => {
    const run = ++analysisRunRef.current, { gid, wid } = createRun(source);
    emit('generation_started', { generation_id: gid, world_id: wid, song_source: source });
    if (trackUrlRef.current) URL.revokeObjectURL(trackUrlRef.current);
    const url = URL.createObjectURL(file); trackUrlRef.current = url;
    setDna(null); setDuration(0); setProgress(.02); setTrack({ name: label || file.name.replace(/\.[^.]+$/, ''), url, size: file.size });
    setStatus('Analyzing rhythm, structure, texture and dynamics...');
    try {
      const result = await analyzeFile(file, n => { if (run === analysisRunRef.current) setProgress(n); }, () => run !== analysisRunRef.current, knownBpm);
      if (run !== analysisRunRef.current) return false;
      setDna(result);
      setAnalysisReady(true); setDuration(result.duration); setProgress(1); setStatus(`WORLD ${wid} ready · ${result.sections.length} sections · ${result.bpm} BPM`);
      emit('generation_completed', { generation_id: gid, world_id: wid, song_source: source });
      return true;
    } catch (err) {
      if (run !== analysisRunRef.current) return false;
      if (trackUrlRef.current === url) { URL.revokeObjectURL(url); trackUrlRef.current = null; setTrack(null); }
      setProgress(0);
    setAnalysisReady(false); throw err;
    }
  };
  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const input = e.target, file = input.files?.[0]; if (!file) return;
    if (!(file.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.name))) { setStatus('Choose MP3, WAV, M4A, AAC, OGG or FLAC.'); input.value = ''; return; }
    trackLoadRunRef.current++; setLoadingTrack(null); emit('song_uploaded', { file_type: file.type || 'unknown' });
    try { await adoptFile(file, undefined, null, 'upload'); } catch { setStatus('Could not decode this track. Try another audio format.'); setProgress(0); } finally { input.value = ''; }
  };
  const searchCatalog = async () => {
    const term = query.trim(); if (term.length < 2) return;
    const run = ++searchRunRef.current; setSearching(true); setCatalogMessage('');
    try { const response = await api.get(`/api/catalog/search?q=${encodeURIComponent(term)}&user=${encodeURIComponent(userId())}`); if (run !== searchRunRef.current) return; setCatalogConfigured(Boolean(response.data?.configured)); setResults(response.data?.tracks || []); if (!response.data?.configured) setCatalogMessage('Epidemic Sound is not connected.'); }
    catch (err) { if (run === searchRunRef.current) setCatalogMessage(err instanceof Error ? err.message : 'Search failed.'); }
    finally { if (run === searchRunRef.current) setSearching(false); }
  };
  const chooseCatalogTrack = async (item: CatalogTrack) => {
    const run = ++trackLoadRunRef.current; analysisRunRef.current++; setLoadingTrack(item.id); setCatalogMessage(''); emit('song_selected', { song_source: 'search' });
    try {
      const response = await api.get(`/api/catalog/track/${encodeURIComponent(item.id)}?user=${encodeURIComponent(userId())}`); if (run !== trackLoadRunRef.current) return;
      const url = response.data?.url; if (!url) throw new Error('No playable URL returned.');
      setStatus(`Loading ${item.title}...`); const downloaded = await fetch(url); if (!downloaded.ok) throw new Error(`Audio download failed (${downloaded.status}).`);
      const blob = await downloaded.blob(); if (run !== trackLoadRunRef.current) return;
      await adoptFile(new File([blob], `${item.title}.mp3`, { type: blob.type || 'audio/mpeg' }), `${item.title} — ${item.artist}`, item.bpm, 'search');
      setSearchOpen(false);
    } catch (err) { if (run === trackLoadRunRef.current) setCatalogMessage(err instanceof Error ? err.message : 'Could not load this track.'); }
    finally { if (run === trackLoadRunRef.current) setLoadingTrack(null); }
  };
  const chooseFeaturedTrack = async (item: FeaturedTrack) => {
    const run = ++trackLoadRunRef.current; analysisRunRef.current++; setLoadingTrack(item.id); emit('song_selected', { song_source: 'featured', featured_track_id: item.id });
    try {
      setStatus(`Loading ${item.title}...`);
      const downloaded = await fetch(item.url, { mode: 'cors' });
      if (!downloaded.ok) throw new Error(`Audio download failed (${downloaded.status}).`);
      const blob = await downloaded.blob(); if (run !== trackLoadRunRef.current) return;
      await adoptFile(new File([blob], `${item.id}.mp3`, { type: blob.type || 'audio/mpeg' }), `${item.title} — ${item.artist}`, null, 'featured');
      setFeaturedOpen(false);
    } catch (err) {
      if (run === trackLoadRunRef.current) setStatus(err instanceof Error ? err.message : 'Could not load this track.');
    } finally {
      if (run === trackLoadRunRef.current) setLoadingTrack(null);
    }
  };

  const toggle = async () => {
    const audio = audioRef.current; if (!track || !audio) return;
    try { await connect(); if (audio.paused) { await audio.play(); setPlaying(true); setStatus(`Playing · WORLD ${worldId}`); } else { audio.pause(); setPlaying(false); setStatus(`Paused · WORLD ${worldId}`); } }
    catch (err) { setPlaying(false); setStatus(`Playback failed: ${err instanceof Error ? err.message : 'browser blocked playback'}`); }
  };
  const seek = (value: number) => { timeRef.current = value; setTime(value); if (audioRef.current) audioRef.current.currentTime = value; };
  const remix = () => {
    const parent = worldId, seed = freshSeed(), gid = crypto.randomUUID(), wid = worldFromSeed(seed);
    emit('remix_clicked', { remix_parent_world_id: parent });
    setParentWorldId(parent); setVisualSeed(seed); setGenerationId(gid);
    identityRef.current = { generationId: gid, worldId: wid, songSource, parentWorldId: parent };
    emit('generation_started', { generation_id: gid, world_id: wid, remix_parent_world_id: parent }); emit('generation_completed', { generation_id: gid, world_id: wid, remix_parent_world_id: parent, remix: true });
    setStatus(`WORLD ${wid} generated from ${parent}`);
  };

  const cycleQuality = () => setQuality(q => q === 'performance' ? 'balanced' : q === 'balanced' ? 'cinematic' : 'performance');
  const clearTrack = () => {
    analysisRunRef.current++; trackLoadRunRef.current++; audioRef.current?.pause(); if (trackUrlRef.current) { URL.revokeObjectURL(trackUrlRef.current); trackUrlRef.current = null; }
    setProgress(0); setPlaying(false); setDna(null); setTrack(null); setDuration(0); setTime(0); setSongSource(null); setStatus('Choose a song to create a world'); timeRef.current = 0; lastVisualTimeRef.current = Number.NaN;
  };
  const fmt = (n: number) => `${Math.floor(n / 60)}:${Math.floor(n % 60).toString().padStart(2, '0')}`;
  const openExpert = () => { setRightOpen(false); setLeftOpen(true); if (!expert) { setExpert(true); emit('simple_to_expert_switched'); } };
  const closeExpert = () => { setLeftOpen(false); setExpert(false); };
  const shareLink = () => { const url = new URL(window.location.href); url.searchParams.set('ref', worldId); return url.toString(); };
  const copyLink = async () => { try { await navigator.clipboard.writeText(shareLink()); setShareMessage('World link copied'); emit('share_invoked', { share_source: 'copy_link' }); } catch { setShareMessage('Copy failed — use the browser address bar.'); } };
  const shareCurrent = async () => {
    try {
      const url = shareLink();
      if (recordBlob) {
        const ext = recordMime.includes('mp4') ? 'mp4' : 'webm';
        const file = new File([recordBlob], `${safeName(track?.name || 'Visual-X')}_World-${worldId}.${ext}`, { type: recordMime });
        if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) { await navigator.share({ title: `Visual.X · WORLD ${worldId}`, text: 'See what this song became in Visual.X.', files: [file], url }); emit('share_invoked', { share_source: 'native_file' }); return; }
      }
      if (navigator.share) { await navigator.share({ title: `Visual.X · WORLD ${worldId}`, text: 'See what this song became in Visual.X.', url }); emit('share_invoked', { share_source: 'native_link' }); return; }
      await copyLink();
    } catch (err) { if ((err as Error).name !== 'AbortError') setShareMessage('Sharing was not available.'); }
  };

  const outputSize = (aspect: Aspect) => aspect === '9:16' ? { w: 720, h: 1280 } : aspect === '1:1' ? { w: 900, h: 900 } : { w: 1280, h: 720 };
  const drawCover = (ctx: CanvasRenderingContext2D, source: HTMLCanvasElement, w: number, h: number) => {
    const sw = source.width || 1, sh = source.height || 1, sourceRatio = sw / sh, targetRatio = w / h;
    let sx = 0, sy = 0, cropW = sw, cropH = sh;
    if (sourceRatio > targetRatio) { cropW = sh * targetRatio; sx = (sw - cropW) / 2; } else { cropH = sw / targetRatio; sy = (sh - cropH) / 2; }
    ctx.drawImage(source, sx, sy, cropW, cropH, 0, 0, w, h);
  };
  const drawBrand = (ctx: CanvasRenderingContext2D, w: number, h: number, endCard: boolean) => {
    if (endCard) {
      ctx.fillStyle = '#030307'; ctx.fillRect(0, 0, w, h); const gradient = ctx.createLinearGradient(w * .2, h * .25, w * .8, h * .75); gradient.addColorStop(0, '#ff2ba6'); gradient.addColorStop(.52, '#8b5cf6'); gradient.addColorStop(1, '#22d3ee'); ctx.fillStyle = gradient; ctx.textAlign = 'center'; ctx.font = `900 ${Math.max(34, Math.round(w * .07))}px Inter, sans-serif`; ctx.fillText('Made with visual.X', w / 2, h * .46); ctx.fillStyle = 'rgba(255,255,255,.82)'; ctx.font = `600 ${Math.max(18, Math.round(w * .032))}px Inter, sans-serif`; ctx.fillText('planet-X.co', w / 2, h * .53); ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.font = `700 ${Math.max(14, Math.round(w * .024))}px Inter, sans-serif`; ctx.fillText(`WORLD ${worldId}`, w / 2, h * .59); return;
    }
    ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,255,255,.46)'; ctx.font = `600 ${Math.max(12, Math.round(w * .018))}px Inter, sans-serif`; ctx.fillText('visual.X · planet-X.co', Math.round(w * .035), Math.round(h * .955));
  };
  const startRecording = async () => {
    const audio = audioRef.current, sourceCanvas = canvasRef.current;
    if (!track || !dna || !audio || !sourceCanvas || recording) return;
    setRecordError('');
    if (typeof MediaRecorder === 'undefined' || !sourceCanvas.captureStream) { const message = 'Recording is not supported in this browser.'; setRecordError(message); setStatus(message); return; }
    try { await connect(); } catch { const message = 'Audio capture could not be initialized on this device.'; setRecordError(message); setStatus(message); return; }
    const ctx = ctxRef.current, analyser = analyserRef.current; if (!ctx || !analyser) { const message = 'Audio capture is unavailable on this device.'; setRecordError(message); setStatus(message); return; }
    const { w, h } = outputSize(recordAspect), output = document.createElement('canvas'); output.width = w; output.height = h; const drawCtx = output.getContext('2d'); if (!drawCtx) return;
    const video = output.captureStream(30), audioDest = ctx.createMediaStreamDestination(), captureGain = ctx.createGain(); analyser.connect(captureGain); captureGain.connect(audioDest);
    const combined = new MediaStream([...video.getVideoTracks(), ...audioDest.stream.getAudioTracks()]);
    const mime = ['video/webm;codecs=vp8,opus', 'video/webm', 'video/webm;codecs=vp9,opus', 'video/mp4;codecs=avc1,mp4a.40.2'].find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';
    let recorder: MediaRecorder;
    try { recorder = new MediaRecorder(combined, { mimeType: mime }); } catch { combined.getTracks().forEach(t => t.stop()); try { analyser.disconnect(captureGain); } catch {} const message = 'This browser could not start a compatible video recorder.'; setRecordError(message); setStatus(message); return; }
    const chunks: Blob[] = [];
    const remaining = Math.max(1, (duration || dna.duration) - audio.currentTime), seconds = recordLength === 'full' ? remaining : Math.min(recordLength, remaining);
    let endCard = false, finishing = false, failed = false, drawRaf = 0, contentTimer = 0, stopTimer = 0; const startedAt = performance.now();
    const cleanup = () => { cancelAnimationFrame(drawRaf); clearTimeout(contentTimer); clearTimeout(stopTimer); try { analyser.disconnect(captureGain); } catch {} combined.getTracks().forEach(t => t.stop()); recordFinishRef.current = null; };
    const finish = () => { if (finishing) return; finishing = true; endCard = true; captureGain.gain.setValueAtTime(0, ctx.currentTime); setRecordingProgress(1); stopTimer = window.setTimeout(() => { if (recorder.state !== 'inactive') recorder.stop(); }, 1200); };
    const draw = () => { if (!endCard) { drawCtx.fillStyle = '#000'; drawCtx.fillRect(0, 0, w, h); drawCover(drawCtx, sourceCanvas, w, h); } drawBrand(drawCtx, w, h, endCard); if (!endCard) setRecordingProgress(Math.min(1, (performance.now() - startedAt) / (seconds * 1000))); drawRaf = requestAnimationFrame(draw); };
    recordFinishRef.current = finish;
    recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    recorder.onerror = () => { failed = true; setRecordError('Recording failed on this device. Try a shorter clip or another browser.'); setStatus('Recording failed on this device.'); if (recorder.state !== 'inactive') recorder.stop(); };
    recorder.onstop = () => { cleanup(); setRecording(false); setRecordingProgress(0); const usable = chunks.some(chunk => chunk.size > 0); if (failed || !usable) { setRecordOpen(true); if (!recordError) setRecordError('No playable clip was produced. Try a shorter clip or another browser.'); return; } const blob = new Blob(chunks, { type: mime }); if (recordUrlRef.current) URL.revokeObjectURL(recordUrlRef.current); const url = URL.createObjectURL(blob); recordUrlRef.current = url; setRecordBlob(blob); setRecordUrl(url); setRecordMime(mime); emit('record_completed', { duration_seconds: seconds, aspect_ratio: recordAspect, export_format: mime.includes('mp4') ? 'mp4' : 'webm' }); setStatus(`Clip ready · WORLD ${worldId}`); };
    setRecordBlob(null); setRecordUrl(null); setRecordMime(mime); setShareMessage('');
    try { recorder.start(1000); } catch { cleanup(); const message = 'Recording could not start on this browser.'; setRecordError(message); setStatus(message); return; }
    setRecording(true); setRecordOpen(false); emit('record_started', { duration_seconds: seconds, aspect_ratio: recordAspect, export_format: mime.includes('mp4') ? 'mp4' : 'webm' }); draw(); if (audio.paused) { try { await audio.play(); setPlaying(true); } catch { finish(); } } audio.addEventListener('ended', finish, { once: true }); contentTimer = window.setTimeout(finish, seconds * 1000);
  };
  const downloadClip = () => {
    if (!recordBlob || !recordUrl) return; const ext = recordMime.includes('mp4') ? 'mp4' : 'webm', link = document.createElement('a'); link.href = recordUrl; link.download = `${safeName(track?.name || 'Visual-X')}_World-${worldId}.${ext}`; document.body.appendChild(link); link.click(); link.remove(); emit('export_completed', { export_format: ext, aspect_ratio: recordAspect }); setShareMessage(`${ext.toUpperCase()} exported`);
  };

  return <main className={`visualApp text-white ${playing ? 'isPlaying' : ''} ${expert ? 'isExpert' : 'isSimple'} ${controlsVisible ? 'controlsVisible' : 'controlsHidden'}`}><audio ref={audioRef} preload='auto' playsInline className='hidden' onLoadedMetadata={e => { const d = e.currentTarget.duration; if (Number.isFinite(d) && d > 0) setDuration(d); }} onCanPlay={() => setAudioReady(true)} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onTimeUpdate={e => { timeRef.current = e.currentTarget.currentTime; setTime(e.currentTarget.currentTime); }} onEnded={() => { setPlaying(false); setStatus(track ? `Finished · WORLD ${worldId}` : 'Finished'); }} onError={() => { setAudioReady(false); setAnalysisReady(false); setPlaying(false); setStatus('Audio could not be loaded or decoded in this browser.'); }} /><input ref={fileRef} className='hidden' type='file' accept='audio/*' onChange={onFile} /><div className='appFrame'><div className='prototypeTop uiChrome'><a href='https://planet-x.co' onClick={() => emit('planetx_conversion', { share_source: 'brand_link' })} className='prototypeBrand wordmarkBrand' aria-label='visual.X on planet.X'><img src='./resources/new-transparent-visual-x-wordmark-asset.png' alt='visual.X' /></a><div className='prototypeTagline'><span>Your Song.</span><small>A World That Only Exists Once.</small></div><div className='prototypeVersion' aria-label='Visual.X version'>v4</div>{track && <div className='prototypeWorld'>WORLD {worldId}<i />{currentSection?.label || 'DIRECTED PERFORMANCE'}</div>}</div><section className='experienceShell prototypeShell'><div className='viewerFrame'><div ref={stageRef} role='button' tabIndex={0} className='visualStage relative overflow-hidden bg-black' title={track ? 'Tap viewer to play or pause' : 'Upload or search for music to begin'} onPointerMove={() => { if (track) revealControls(); }} onClick={e => { if ((e.target as HTMLElement).closest('button,label,input')) return; if (track && playing && !expert && !controlsVisible) { revealControls(); return; } if (track && ready) void toggle(); }} onKeyDown={e => { if ((e.key === 'Enter' || e.key === ' ') && track && ready) { e.preventDefault(); void toggle(); } }}><canvas ref={canvasRef} className='h-full w-full' />{!track && <EntryHero onUpload={() => fileRef.current?.click()} onSearch={() => setSearchOpen(true)} onFeatured={() => setFeaturedOpen(true)} />}{track && <><div className='simpleDock uiChrome'><button className={!playing ? 'playActive' : ''} onClick={() => { if (!playing) void toggle(); }} disabled={!ready} aria-label='Play'><Play size={18} /></button><button className={playing ? 'pauseActive' : ''} onClick={() => { if (playing) void toggle(); }} disabled={!ready} aria-label='Pause'><Pause size={18} /></button><button className={recording ? 'recording' : ''} onClick={() => recording ? recordFinishRef.current?.() : (setRecordError(''), setRecordOpen(true))} aria-label={recording ? 'Stop recording' : 'Record'}>{recording ? <Square size={17} /> : <Video size={18} />}</button><button onClick={() => void shareCurrent()} aria-label='Share'><Share2 size={18} /></button></div>{recording && <div className='recordingMeter'><span>REC</span><div><i style={{ width: `${recordingProgress * 100}%` }} /></div><b>{Math.round(recordingProgress * 100)}%</b></div>}</>}{expert && <div className='stageTools uiChrome'><button onClick={() => setShowOverlay(v => !v)} aria-label='Toggle visual overlay'>{showOverlay ? <Eye size={16} /> : <EyeOff size={16} />}</button></div>}{expert && showOverlay && currentSection && <div className='absolute left-5 top-5 flex gap-2'><span className='storyBadge'>{currentSection.label}</span><span className='storyBadge accent'>GROUP {currentSection.repeatGroup}</span>{cue?.hero && <span className='storyBadge callback'>HERO EVENT</span>}</div>}{expert && showOverlay && cue && <div className='directorHud'><div><span>LOOKAHEAD</span><b>{cue.lookahead}</b></div><div><span>CAMERA</span><b>{cue.camera.shot.toUpperCase()} · {Math.round(cue.camera.fov)}°</b></div><div><span>POST</span><b>bloom {cue.post.bloom.toFixed(2)} · exp {cue.post.exposure.toFixed(2)}</b></div></div>}</div>{track && <div className='transport uiChrome'><div className='timelineTimes'><span>{fmt(time)}</span><span>{fmt(duration)}</span></div><div className='timelineRail'><i style={{ width: `${Math.min(100, Math.max(0, (time / Math.max(duration, .001)) * 100))}%` }} /><input aria-label='Track position' type='range' min='0' max={duration || 1} step='.1' value={time} onChange={e => seek(Number(e.target.value))} /></div></div>}</div>{track && <><button className='prototypeEdge prototypeEdgeLeft' aria-label='Open Expert drawer' onClick={openExpert}><ChevronRight size={17} /></button><button className='prototypeEdge prototypeEdgeRight' aria-label='Open actions drawer' onClick={() => { closeExpert(); setRightOpen(true); }}><ChevronLeft size={17} /></button>{(leftOpen || rightOpen) && <button className='drawerBackdrop' aria-label='Close drawers' onClick={() => { closeExpert(); setRightOpen(false); }} />}<aside className={`prototypeDrawer prototypeDrawerLeft ${leftOpen ? 'open' : ''}`} aria-hidden={!leftOpen}><div className='prototypeDrawerHeader'><button onClick={closeExpert}><ChevronLeft size={16} />Back</button><div><span>EXPERT MODE</span><b>WORLD {worldId}</b></div><button aria-label='Close Expert drawer' onClick={closeExpert}><X size={16} /></button></div><div className='prototypeDrawerBody'><ExpertPanel quality={quality} diagnostics={diagnostics} setDiagnostics={setDiagnostics} cycleQuality={cycleQuality} remix={remix} setShowOverlay={setShowOverlay} setSearchOpen={setSearchOpen} dna={dna} time={time} seek={seek} fmt={fmt} metrics={metrics} worldId={worldId} live={live} cue={cue} /></div></aside><aside className={`prototypeDrawer prototypeDrawerRight ${rightOpen ? 'open' : ''}`} aria-hidden={!rightOpen}><div className='prototypeDrawerHeader right'><button aria-label='Close actions drawer' onClick={() => setRightOpen(false)}><X size={16} /></button><div><span>WORLD MENU</span><b>{quality.toUpperCase()}</b></div><button onClick={() => setRightOpen(false)}>Back<ChevronRight size={16} /></button></div><div className='prototypeDrawerBody'><div className='quickMenu'><button onClick={() => { remix(); setRightOpen(false); }}><span><Shuffle size={17} /></span><div><b>remiX</b><small>Generate a new world</small></div></button><button onClick={cycleQuality}><span><Settings2 size={17} /></span><div><b>{quality}</b><small>Tap to cycle quality</small></div></button><button onClick={() => { setSearchOpen(true); setRightOpen(false); }}><span><Music2 size={17} /></span><div><b>Change music</b><small>Search or upload another song</small></div></button><button onClick={() => { clearTrack(); setRightOpen(false); }}><span><X size={17} /></span><div><b>Clear song</b><small>Return to the entry screen</small></div></button><a href='https://planet-x.co' onClick={() => emit('planetx_conversion', { share_source: 'world_menu' })}><span><ExternalLink size={17} /></span><div><b>planet.X</b><small>Open the planet.X ecosystem</small></div></a></div></div></aside></>}</section></div>{featuredOpen && <FeaturedModal tracks={featuredTracks} loadingTrack={loadingTrack} onChoose={chooseFeaturedTrack} onClose={() => setFeaturedOpen(false)} />}
{searchOpen && <SearchModal query={query} setQuery={setQuery} searching={searching} searchCatalog={searchCatalog} catalogConfigured={catalogConfigured} catalogMessage={catalogMessage} results={results} loadingTrack={loadingTrack} chooseCatalogTrack={chooseCatalogTrack} progress={progress} onUpload={() => { setSearchOpen(false); fileRef.current?.click(); }} onClose={() => setSearchOpen(false)} />}{recordOpen && <RecordModal worldId={worldId} recordLength={recordLength} setRecordLength={setRecordLength} recordAspect={recordAspect} setRecordAspect={setRecordAspect} error={recordError} onStart={() => void startRecording()} onClose={() => setRecordOpen(false)} />}{recordUrl && recordBlob && <PreviewTray recordUrl={recordUrl} recordMime={recordMime} trackName={track?.name || ''} worldId={worldId} shareMessage={shareMessage} onDownload={downloadClip} onShare={() => void shareCurrent()} onCopy={() => void copyLink()} onClose={() => { if (recordUrlRef.current) { URL.revokeObjectURL(recordUrlRef.current); recordUrlRef.current = null; } setRecordUrl(null); setRecordBlob(null); }} />}<div className='sr-only' aria-live='polite'>{status}</div></main>;
}

function EntryHero({ onUpload, onSearch, onFeatured }: { onUpload: () => void; onSearch: () => void; onFeatured: () => void }) { return <div className='entryHero'><div className='entryOrb'>X</div><p className='entryKicker'>SEE WHAT YOUR SONG BECOMES</p><h2>Choose a song.<br /><span>Watch a world emerge.</span></h2><p className='entryCopy'>Local song analysis · procedural 360° worlds · no AI inference.</p><div className='entryActions'><button onClick={onUpload} className='heroAction primary'><Upload size={20} />Upload Song</button><button onClick={onSearch} className='heroAction'><Search size={20} />Search Music</button><button onClick={onFeatured} className='heroAction'><Music2 size={20} />Try an xFactor Track</button></div></div>; }
function ExpertPanel(props: { quality: QualityTier; diagnostics: boolean; setDiagnostics: (v: boolean | ((x: boolean) => boolean)) => void; cycleQuality: () => void; remix: () => void; setShowOverlay: (v: boolean | ((x: boolean) => boolean)) => void; setSearchOpen: (v: boolean) => void; dna: SongDNA | null; time: number; seek: (n: number) => void; fmt: (n: number) => string; metrics: [string, number][]; worldId: string; live: LiveFrame; cue: Cue | null }) {
  const p = props;
  const [tab, setTab] = useState<'world' | 'dna' | 'director' | 'live'>('world');
  const tabs = [['world', 'World'], ['dna', 'DNA'], ['director', 'Director'], ['live', 'Live']] as const;
  return <aside className='expertPanel expertDeck'><div className='expertTabs'>{tabs.map(([id, label]) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}><span>X</span><b>{label}</b></button>)}</div><div className='expertPane'>{tab === 'world' && <div className='panel deckPanel'><div className='deckTitle'><div><p className='eyebrow'>WORLD CONTROL</p><h3>WORLD {p.worldId}</h3></div><button onClick={() => p.setDiagnostics(v => !v)} className={`diagButton ${p.diagnostics ? 'active' : ''}`}>DIAG</button></div><div className='deckActions'><button onClick={p.cycleQuality}><span>Quality</span><b>{p.quality}</b></button><button onClick={p.remix}><span>World</span><b>remiX</b></button><button onClick={() => p.setShowOverlay(v => !v)}><span>HUD</span><b>Overlay</b></button><button onClick={() => p.setSearchOpen(true)}><span>Source</span><b>Music</b></button></div><div className='planetSignature'><strong>X</strong><div><b>planet.X direction engine</b><span>Deterministic performance · local analysis</span></div></div></div>}{tab === 'dna' && <div className='panel deckPanel'>{p.dna ? <><div className='deckTitle'><div><p className='eyebrow'>SONG DNA</p><h3>Structural fingerprint</h3></div><div className='dnaTempo'><b>{p.dna.bpm}</b><span>BPM · {Math.round(p.dna.tempoConfidence * 100)}%</span></div></div><div className='dnaCompact'>{p.metrics.map(([k, v]) => <div key={k}><span>{k}</span><i><em style={{ width: `${pct(v)}%` }} /></i><b>{pct(v)}</b></div>)}</div></> : <div className='deckEmpty'>Analyze a song to reveal its DNA.</div>}</div>}{tab === 'director' && <div className='panel deckPanel directorDeck'><div className='deckTitle'><div><p className='eyebrow'>DIRECTOR</p><h3>Performance timeline</h3></div>{p.cue && <span className='cueChip'>{p.cue.camera.shot}</span>}</div>{p.dna ? <div className='directorList'>{p.dna.sections.map((s, i) => <button key={i} className={`storyRow ${p.time >= s.start && p.time < s.end ? 'current' : ''}`} onClick={() => p.seek(s.start + .05)}><span>{p.fmt(s.start)}</span><strong>{s.label}</strong><em>G{s.repeatGroup} · {pct(s.importance)}</em></button>)}</div> : <div className='deckEmpty'>No director plan yet.</div>}</div>}{tab === 'live' && <div className='panel deckPanel'><div className='deckTitle'><div><p className='eyebrow'>LIVE TELEMETRY</p><h3>Engine pulse</h3></div><Activity size={18} className='text-cyan-300' /></div><div className='liveGrid'><Stat label='Bass' value={p.live.bass} /><Stat label='Mids' value={p.live.mid} /><Stat label='Highs' value={p.live.treble} /><Stat label='Flux' value={p.live.flux} /><Stat label='Beat' value={p.cue?.beatPulse || 0} /></div>{p.cue && <div className='cueReadout'><div><span>LOOKAHEAD</span><b>{p.cue.lookahead}</b></div><div><span>CAMERA</span><b>{p.cue.camera.shot.toUpperCase()} · {Math.round(p.cue.camera.fov)}°</b></div><div><span>POST</span><b>{p.cue.post.bloom.toFixed(2)} / {p.cue.post.exposure.toFixed(2)}</b></div></div>}</div>}</div></aside>;
}
function FeaturedModal(props: { tracks: FeaturedTrack[]; loadingTrack: string | null; onChoose: (t: FeaturedTrack) => Promise<void>; onClose: () => void }) { const p = props; return <Modal onClose={p.onClose}><p className='eyebrow'>TRY VISUAL.X NOW</p><h2 className='modalTitle'>Choose an xFactor track</h2><p className='mt-2 text-sm text-zinc-400'>No upload needed. Pick a track and Visual.X will analyze it just like your own song.</p><div className='mt-4 space-y-2'>{p.tracks.map(t => <button key={t.id} onClick={() => void p.onChoose(t)} disabled={p.loadingTrack !== null} className='trackResult'><div className='grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-pink-500/30 to-cyan-400/20'><Music2 size={16} /></div><div className='min-w-0 flex-1'><div className='truncate text-sm font-semibold'>{t.title}</div><div className='truncate text-[11px] text-zinc-500'>{t.artist}</div></div>{p.loadingTrack === t.id ? <LoaderCircle size={16} className='animate-spin' /> : <Play size={15} />}</button>)}</div></Modal>; }

function SearchModal(props: { query: string; setQuery: (v: string) => void; searching: boolean; searchCatalog: () => Promise<void>; catalogConfigured: boolean | null; catalogMessage: string; results: CatalogTrack[]; loadingTrack: string | null; chooseCatalogTrack: (t: CatalogTrack) => Promise<void>; progress: number; onUpload: () => void; onClose: () => void }) { const p = props; return <Modal onClose={p.onClose}><p className='eyebrow'>SEARCH MUSIC</p><h2 className='modalTitle'>Choose a track</h2><div className='mt-4 flex gap-2'><div className='relative flex-1'><Search size={15} className='absolute left-3 top-3 text-zinc-500' /><input autoFocus value={p.query} onChange={e => p.setQuery(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void p.searchCatalog(); }} placeholder='Search Epidemic Sound...' className='modalInput pl-9' /></div><button onClick={() => void p.searchCatalog()} disabled={p.searching || p.query.trim().length < 2} className='modalIcon'>{p.searching ? <LoaderCircle size={17} className='animate-spin' /> : <Search size={17} />}</button></div><div className='mt-3 flex justify-between text-[10px] uppercase tracking-[.16em] text-zinc-500'><span>Epidemic Sound</span><span className={p.catalogConfigured ? 'text-emerald-400' : 'text-amber-400'}>{p.catalogConfigured === null ? 'checking' : p.catalogConfigured ? 'connected' : 'setup needed'}</span></div>{p.catalogMessage && <p className='mt-2 text-xs text-amber-300'>{p.catalogMessage}</p>}{p.results.length > 0 && <div className='mt-4 max-h-[45vh] space-y-2 overflow-auto'>{p.results.map(t => <button key={t.id} onClick={() => void p.chooseCatalogTrack(t)} disabled={p.loadingTrack !== null} className='trackResult'><div className='grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-lg bg-gradient-to-br from-pink-500/30 to-cyan-400/20'>{t.image ? <img src={t.image} alt='' className='h-full w-full object-cover' /> : <Music2 size={16} />}</div><div className='min-w-0 flex-1'><div className='truncate text-sm font-semibold'>{t.title}</div><div className='truncate text-[11px] text-zinc-500'>{t.artist}{t.bpm ? ` · ${Math.round(t.bpm)} BPM` : ''}</div></div>{p.loadingTrack === t.id ? <LoaderCircle size={16} className='animate-spin' /> : <Play size={15} />}</button>)}</div>}<div className='my-4 flex items-center gap-3 text-[9px] uppercase tracking-[.18em] text-zinc-600'><span className='h-px flex-1 bg-white/5' /><span>or</span><span className='h-px flex-1 bg-white/5' /></div><button onClick={p.onUpload} className='heroAction w-full'><Upload size={18} />Upload your own song</button>{p.progress > 0 && p.progress < 1 && <div className='mt-4'><div className='mb-1 flex justify-between text-xs text-zinc-500'><span>Deep DSP analysis</span><span>{Math.round(p.progress * 100)}%</span></div><div className='h-1.5 rounded-full bg-white/5'><div className='dnaBar h-full rounded-full' style={{ width: `${p.progress * 100}%` }} /></div></div>}</Modal>; }
function RecordModal(props: { worldId: string; recordLength: RecordLength; setRecordLength: (v: RecordLength) => void; recordAspect: Aspect; setRecordAspect: (v: Aspect) => void; error: string; onStart: () => void; onClose: () => void }) { const p = props; return <Modal onClose={p.onClose}><p className='eyebrow'>RECORD WORLD {p.worldId}</p><h2 className='modalTitle'>Create a shareable clip</h2><p className='modalCopy'>The export captures the rendered world plus synchronized audio — never the surrounding app UI.</p>{p.error && <div className='recordError' role='alert'>{p.error}</div>}<label className='optionLabel'>Length</label><div className='optionGrid four'>{([15, 30, 60, 'full'] as RecordLength[]).map(v => <button key={String(v)} onClick={() => p.setRecordLength(v)} className={p.recordLength === v ? 'selected' : ''}>{v === 'full' ? 'Full segment' : `${v}s`}</button>)}</div><label className='optionLabel'>Aspect ratio</label><div className='optionGrid three'>{(['9:16', '1:1', '16:9'] as Aspect[]).map(v => <button key={v} onClick={() => p.setRecordAspect(v)} className={p.recordAspect === v ? 'selected' : ''}><b>{v}</b><span>{v === '9:16' ? 'Reels · TikTok · Shorts' : v === '1:1' ? 'Social feed' : 'YouTube · desktop'}</span></button>)}</div><button onClick={p.onStart} className='heroAction primary mt-6 w-full'><Video size={19} />Start Recording</button><p className='mt-3 text-center text-[10px] text-zinc-500'>Exports include a subtle visual.X · planet-X.co mark and a 1.2s end card.</p></Modal>; }
function PreviewTray(props: { recordUrl: string; recordMime: string; trackName: string; worldId: string; shareMessage: string; onDownload: () => void; onShare: () => void; onCopy: () => void; onClose: () => void }) { const p = props; return <div className='previewTray'><div className='previewTop'><div><p className='eyebrow'>CLIP READY</p><b>{p.trackName} · WORLD {p.worldId}</b></div><button onClick={p.onClose}><X size={16} /></button></div><video src={p.recordUrl} controls playsInline /><div className='previewActions'><button onClick={p.onDownload}><Download size={17} />Export {p.recordMime.includes('mp4') ? 'MP4' : 'WebM'}</button><button onClick={p.onShare}><Share2 size={17} />Share</button><button onClick={p.onCopy}><Copy size={17} />Copy Link</button></div>{p.shareMessage && <p>{p.shareMessage}</p>}</div>; }
function Modal({ children, onClose }: { children: ReactNode; onClose: () => void }) { useEffect(() => { const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); }; document.addEventListener('keydown', onKey); return () => document.removeEventListener('keydown', onKey); }, [onClose]); return <div className='modalBackdrop' role='presentation' onPointerDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className='modalCard' role='dialog' aria-modal='true'><button type='button' aria-label='Close dialog' className='modalClose' onClick={onClose}><X size={17} /></button>{children}</div></div>; }
function Stat({ label, value }: { label: string; value: number }) { return <div className='rounded-xl border border-white/5 bg-white/[.025] px-1 py-3'><div className='text-base font-bold'>{Math.round(value * 100)}</div><div className='text-[8px] uppercase tracking-[.12em] text-zinc-500'>{label}</div></div>; }
function Funnel({ label, value }: { label: string; value: number }) { return <div><b>{value}</b><span>{label}</span></div>; }
export default App;

